# Smart Esquadrias Backend — v5.41.0

Backend do sistema Smart Esquadrias: cálculo técnico, custos, formação de preço, orçamento persistido, estoque, reservas, ordens de produção, auditoria e preparação para PostgreSQL.

## Estado atual
- Python + FastAPI + SQLAlchemy + PostgreSQL como banco de referência.
- SQLite permitido apenas para desenvolvimento/testes funcionais.
- Multiempresa por `company_id` em preços, orçamentos, estoque, reservas e produção.
- Fluxo persistido: **Orçamento → OP → Reserva → Produção → Consumo**.
- Snapshots técnicos preservam o estado usado na criação da OP/orçamento.
- Auditoria operacional e `X-Request-ID`.
- Migrations canônicas em `database/migrations`.
- Concorrência real requer execução contra PostgreSQL.

## Executar testes
```bash
pip install -r requirements.txt
pytest -q
```

O `pytest.ini` já define `pythonpath = .`, portanto o teste é reproduzível independentemente do `PYTHONPATH` herdado do ambiente.

## PostgreSQL local
```bash
./scripts/postgres_test.sh
```

O script sobe PostgreSQL, aguarda disponibilidade, aplica migrations e executa os testes marcados como `postgres`.

## Produção
Defina `APP_ENV=production`, `DATABASE_URL` apontando para PostgreSQL, `APP_SECRET_KEY` forte e `AUTO_CREATE_SCHEMA=false`. Aplique as migrations antes de iniciar a API.

## Segurança
- Senhas com PBKDF2-HMAC-SHA256.
- Tokens HMAC-SHA256 com expiração.
- Isolamento por empresa derivado do token, nunca do payload.
- Rate limit básico de login por processo; em produção, complemente com proxy/WAF ou mecanismo distribuído.
- Headers de segurança e documentação OpenAPI desabilitada em produção.
- Auditoria não grava senhas, tokens ou hashes.

## Regra técnica crítica
**MP-352 é exclusivo dos modelos de 4 folhas e não pode aparecer no Modelo 001 de 2 folhas.**

## Limites conhecidos
- A concorrência PostgreSQL ainda precisa ser executada em um servidor PostgreSQL real.
- Alocação automática de barras por comprimento não foi inventada; a reserva usa `item_id` e quantidade explícitos.
- Modelos e regras técnicas ainda são globais; a parametrização completa de modelos é uma próxima camada do produto.


## Etapa 56 — Motor de modelos e validação (v5.38)
- O cálculo agora passa por um registro de modelos (`calculate_model`).
- O código do modelo é normalizado e modelos não cadastrados são rejeitados pelo motor.
- `calculate_model_001` permanece como compatibilidade explícita do MOD-001.
- A validação dimensional não mantém uma segunda lista manual de modelos, evitando divergência entre validação e motor.
- O orçamento persistido grava o `model_code` efetivamente calculado.
- Regra crítica preservada: MP-352 não pertence ao MOD-001 de 2 folhas.
- Suíte: 98 testes passaram; 1 teste PostgreSQL foi ignorado por ausência de PostgreSQL real.


## Etapa 57 — famílias e expansão futura
- O catálogo possui seções para Esquadrias, Portões, Grades, Boxes, Guarda-corpos, Fechamentos, Corrimãos e Outros.
- Apenas as famílias atualmente desenvolvidas devem ser tratadas como ativas; as demais ficam `EM_BREVE`, sem regras técnicas ou preços inventados.
- Endpoint `/catalogo/publico` foi preparado para uma futura vitrine pública e expõe somente código, nome e status.
- A futura vitrine poderá permitir ao cliente escolher modelo, informar medidas e receber somente o valor final; essa experiência não foi ativada nem expõe custos internos nesta etapa.
- A primeira validação comercial deverá usar somente os modelos tecnicamente comprovados (2 e 4 folhas quando ambos estiverem formalmente cadastrados).


## Etapa 59 — Regra definitiva do vidro

Para os dois modelos atualmente validados, o vidro segue a regra técnica confirmada:
- largura do vidro = comprimento do MP-309 − 8 mm;
- altura do vidro = comprimento do MP-300 − 78 mm;
- os 78 mm da altura correspondem a 35 mm de cada MP-309 + 8 mm de folga total.

A regra foi registrada como `VIDRO78` e permanece separada do cálculo de preço.
