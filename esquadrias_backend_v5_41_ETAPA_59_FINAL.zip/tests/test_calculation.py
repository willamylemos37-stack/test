import pytest
from app.services.calculator import calculate_model_001

def test_model_001_has_no_mp352():
    result = calculate_model_001(1000,1000,1)
    assert "MP-352" not in [p["material_code"] for p in result.parts]

def test_glass_clearance():
    result = calculate_model_001(1000,1000,1)
    assert result.glass[0]["width_mm"] == 438
    assert result.glass[0]["height_mm"] == 922

def test_multiple_quantity_scales_parts():
    one = calculate_model_001(1000,1000,1)
    six = calculate_model_001(1000,1000,6)
    assert sum(p["quantity"] for p in six.parts) == 6 * sum(p["quantity"] for p in one.parts)

def test_invalid_dimensions():
    with pytest.raises(ValueError):
        calculate_model_001(108,1000,1)
    with pytest.raises(ValueError):
        calculate_model_001(1000,134,1)


def test_odd_width_rejected_for_integer_mm_cuts():
    with pytest.raises(ValueError):
        calculate_model_001(1001, 1000, 1)


def test_reference_six_windows_cut_quantities():
    result = calculate_model_001(1000, 1000, 6)
    by_code = {}
    for part in result.parts:
        by_code.setdefault((part["material_code"], part["cut_type"], part["length_mm"]), 0)
        by_code[(part["material_code"], part["cut_type"], part["length_mm"])] += part["quantity"]
    assert by_code[("MP-357", "PADRAO", 970)] == 6
    assert by_code[("MP-309", "HORIZONTAL", 446)] == 24
    assert by_code[("BG-202", "VERTICAL", 866)] == 24
    assert result.glass[0]["width_mm"] == 438
    assert result.glass[0]["height_mm"] == 922

def test_unknown_model_is_rejected():
    from app.services.calculator import calculate_model
    with pytest.raises(ValueError, match="Modelo não suportado"):
        calculate_model("MOD-999", 1000, 1000, 1)

def test_model_code_is_normalized():
    from app.services.calculator import calculate_model
    result = calculate_model(" mod-001 ", 1000, 1000, 1)
    assert result.model_code == "MOD-001"
