from dataclasses import dataclass
from typing import Any, Callable

@dataclass
class CalculatedQuote:
    model_code: str
    width_mm: int
    height_mm: int
    quantity: int
    parts: list[dict[str, Any]]
    glass: list[dict[str, Any]]
    accessories: list[dict[str, Any]]
    rule_snapshots: list[dict[str, str]]

@dataclass(frozen=True)
class ModelDefinition:
    code: str
    calculator: Callable[[int, int, int], CalculatedQuote]


def _calculate_model_001(width_mm: int, height_mm: int, quantity: int) -> CalculatedQuote:
    if width_mm <= 0 or height_mm <= 0 or quantity <= 0:
        raise ValueError("Dimensões e quantidade devem ser positivas.")
    if width_mm <= 108 or height_mm <= 134:
        raise ValueError("Dimensões insuficientes para as regras técnicas do MOD-001.")
    if (width_mm - 108) % 2 != 0:
        raise ValueError("A largura do MOD-001 deve produzir meia folha em milímetros inteiros.")
    half_leaf = (width_mm - 108) // 2
    if half_leaf <= 0:
        raise ValueError("Largura insuficiente para a regra do modelo.")
    parts = [
        {"material_code":"MP-357","cut_type":"PADRAO","length_mm":width_mm-30,"quantity":quantity},
        {"material_code":"MP-358","cut_type":"PADRAO","length_mm":width_mm-30,"quantity":quantity},
        {"material_code":"MP-360","cut_type":"PADRAO","length_mm":height_mm,"quantity":2*quantity},
        {"material_code":"MP-300","cut_type":"PADRAO","length_mm":height_mm-40,"quantity":2*quantity},
        {"material_code":"MP-302","cut_type":"PADRAO","length_mm":height_mm-40,"quantity":quantity},
        {"material_code":"MP-321","cut_type":"PADRAO","length_mm":height_mm-40,"quantity":quantity},
        {"material_code":"MP-309","cut_type":"HORIZONTAL","length_mm":half_leaf,"quantity":4*quantity},
        {"material_code":"BG-202","cut_type":"HORIZONTAL","length_mm":half_leaf,"quantity":4*quantity},
        {"material_code":"BG-202","cut_type":"VERTICAL","length_mm":height_mm-134,"quantity":4*quantity},
    ]
    glass = [{"pane":i+1,"width_mm":half_leaf-8,"height_mm":height_mm-78,"quantity":quantity} for i in range(2)]
    accessories = [
        {"item":"ROLDANA","quantity":4*quantity},
        {"item":"FECHO","quantity":quantity},
        {"item":"GUIA_TRAVA","quantity":4*quantity},
        {"item":"PARAFUSO","quantity":16*quantity},
        {"item":"CALCO","quantity":0},
        {"item":"ESCOVA_5MM","length_mm":height_mm + half_leaf*4,"quantity":quantity},
        {"item":"ESCOVA_7MM","length_mm":height_mm*2,"quantity":quantity},
        {"item":"BORRACHA_VEDACAO","length_mm":2*((half_leaf-7)+(height_mm-7))*2,"quantity":quantity},
        {"item":"SILICONE_SELANTE","quantity":quantity/3},
    ]
    snapshots = [
        {"rule_code":"L30","expression_snapshot":"L - 30","value_snapshot":str(width_mm-30)},
        {"rule_code":"H","expression_snapshot":"H","value_snapshot":str(height_mm)},
        {"rule_code":"H40","expression_snapshot":"H - 40","value_snapshot":str(height_mm-40)},
        {"rule_code":"L108_2","expression_snapshot":"(L - 108) / 2","value_snapshot":str(half_leaf)},
        {"rule_code":"H134","expression_snapshot":"H - 134","value_snapshot":str(height_mm-134)},
        {"rule_code":"VIDRO78","expression_snapshot":"largura = MP-309 - 8 mm; altura = MP-300 - 78 mm","value_snapshot":"8 mm na largura; 78 mm na altura"},
    ]
    return CalculatedQuote("MOD-001", width_mm, height_mm, quantity, parts, glass, accessories, snapshots)


_MODEL_REGISTRY: dict[str, ModelDefinition] = {
    "MOD-001": ModelDefinition("MOD-001", _calculate_model_001),
}


def supported_models() -> tuple[str, ...]:
    return tuple(sorted(_MODEL_REGISTRY))


def calculate_model(model_code: str, width_mm: int, height_mm: int, quantity: int) -> CalculatedQuote:
    code = (model_code or "").strip().upper()
    definition = _MODEL_REGISTRY.get(code)
    if definition is None:
        raise ValueError(f"Modelo não suportado: {model_code}.")
    return definition.calculator(width_mm, height_mm, quantity)


def calculate_model_001(width_mm: int, height_mm: int, quantity: int) -> CalculatedQuote:
    return _calculate_model_001(width_mm, height_mm, quantity)
