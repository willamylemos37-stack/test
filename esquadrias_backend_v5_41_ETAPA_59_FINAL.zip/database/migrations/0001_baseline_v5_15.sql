CREATE TABLE IF NOT EXISTS modelos (
  id BIGSERIAL PRIMARY KEY,
  code VARCHAR(30) UNIQUE NOT NULL,
  name VARCHAR(120) NOT NULL,
  leaves INTEGER NOT NULL CHECK (leaves > 0),
  status VARCHAR(30) NOT NULL DEFAULT 'ATIVO'
);

CREATE TABLE IF NOT EXISTS regras_tecnicas (
  id BIGSERIAL PRIMARY KEY,
  code VARCHAR(50) UNIQUE NOT NULL,
  expression VARCHAR(255) NOT NULL,
  description TEXT NOT NULL DEFAULT ''
);

CREATE TABLE IF NOT EXISTS modelo_componentes (
  id BIGSERIAL PRIMARY KEY,
  model_id BIGINT NOT NULL REFERENCES modelos(id),
  material_code VARCHAR(50) NOT NULL,
  quantity INTEGER NOT NULL CHECK (quantity >= 0),
  cut_rule VARCHAR(50) NOT NULL,
  notes TEXT NOT NULL DEFAULT ''
);

CREATE TABLE IF NOT EXISTS orcamentos (
  id BIGSERIAL PRIMARY KEY,
  code VARCHAR(40) UNIQUE NOT NULL,
  model_code VARCHAR(30) NOT NULL,
  width_mm INTEGER NOT NULL CHECK (width_mm > 0),
  height_mm INTEGER NOT NULL CHECK (height_mm > 0),
  quantity INTEGER NOT NULL CHECK (quantity > 0),
  status VARCHAR(30) NOT NULL DEFAULT 'RASCUNHO',
  total_cost NUMERIC(14,2) NOT NULL DEFAULT 0,
  sale_price NUMERIC(14,2) NOT NULL DEFAULT 0,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS orcamento_itens (
  id BIGSERIAL PRIMARY KEY,
  quote_id BIGINT NOT NULL REFERENCES orcamentos(id) ON DELETE CASCADE,
  material_code VARCHAR(50) NOT NULL,
  cut_type VARCHAR(30) NOT NULL,
  length_mm INTEGER NOT NULL CHECK (length_mm > 0),
  quantity INTEGER NOT NULL CHECK (quantity > 0),
  unit_price NUMERIC(14,4) NOT NULL DEFAULT 0,
  total_price NUMERIC(14,2) NOT NULL DEFAULT 0
);

CREATE TABLE IF NOT EXISTS orcamento_regras_snapshot (
  id BIGSERIAL PRIMARY KEY,
  quote_id BIGINT NOT NULL REFERENCES orcamentos(id) ON DELETE CASCADE,
  rule_code VARCHAR(50) NOT NULL,
  expression_snapshot VARCHAR(255) NOT NULL,
  value_snapshot VARCHAR(255) NOT NULL
);

CREATE TABLE IF NOT EXISTS estoque_retals (
  id BIGSERIAL PRIMARY KEY,
  material_code VARCHAR(50) NOT NULL,
  length_mm INTEGER NOT NULL CHECK (length_mm > 0),
  quantity INTEGER NOT NULL DEFAULT 1 CHECK (quantity > 0),
  status VARCHAR(30) NOT NULL DEFAULT 'DISPONIVEL',
  source_quote_code VARCHAR(40),
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS catalogo_precos (
  id BIGSERIAL PRIMARY KEY,
  material_code VARCHAR(50) NOT NULL,
  description VARCHAR(160) NOT NULL,
  variant VARCHAR(40) NOT NULL DEFAULT 'PADRAO',
  unit VARCHAR(20) NOT NULL,
  price NUMERIC(14,4) NOT NULL DEFAULT 0 CHECK (price >= 0),
  supplier VARCHAR(120),
  active VARCHAR(20) NOT NULL DEFAULT 'ATIVO'
);

CREATE TABLE IF NOT EXISTS historico_precos (
  id BIGSERIAL PRIMARY KEY,
  material_code VARCHAR(50) NOT NULL,
  variant VARCHAR(40) NOT NULL DEFAULT 'PADRAO',
  price NUMERIC(14,4) NOT NULL CHECK (price >= 0),
  unit VARCHAR(20) NOT NULL,
  supplier VARCHAR(120),
  valid_from TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  source VARCHAR(120) NOT NULL DEFAULT 'CADASTRO'
);

CREATE TABLE IF NOT EXISTS orcamento_precos_snapshot (
  id BIGSERIAL PRIMARY KEY,
  quote_id BIGINT NOT NULL REFERENCES orcamentos(id) ON DELETE CASCADE,
  material_code VARCHAR(50) NOT NULL,
  variant VARCHAR(40) NOT NULL,
  unit VARCHAR(20) NOT NULL,
  unit_price NUMERIC(14,4) NOT NULL DEFAULT 0,
  supplier VARCHAR(120)
);

CREATE TABLE IF NOT EXISTS orcamento_formacao_preco_snapshot (
  id BIGSERIAL PRIMARY KEY,
  quote_id BIGINT NOT NULL REFERENCES orcamentos(id) ON DELETE CASCADE,
  method VARCHAR(20) NOT NULL,
  material_cost NUMERIC(14,2) NOT NULL DEFAULT 0,
  labor_total NUMERIC(14,2) NOT NULL DEFAULT 0,
  indirect_variable NUMERIC(14,2) NOT NULL DEFAULT 0,
  indirect_fixed NUMERIC(14,2) NOT NULL DEFAULT 0,
  freight NUMERIC(14,2) NOT NULL DEFAULT 0,
  tax_percent NUMERIC(8,4) NOT NULL DEFAULT 0,
  tax_amount NUMERIC(14,2) NOT NULL DEFAULT 0,
  target_margin_percent NUMERIC(8,4),
  target_markup_percent NUMERIC(8,4),
  base_cost NUMERIC(14,2) NOT NULL DEFAULT 0,
  sale_price NUMERIC(14,2) NOT NULL DEFAULT 0,
  profit NUMERIC(14,2) NOT NULL DEFAULT 0,
  effective_margin_percent NUMERIC(8,4) NOT NULL DEFAULT 0,
  effective_markup_percent NUMERIC(8,4) NOT NULL DEFAULT 0
);

CREATE INDEX IF NOT EXISTS idx_orcamentos_status ON orcamentos(status);
CREATE INDEX IF NOT EXISTS idx_orcamentos_model_code ON orcamentos(model_code);
CREATE INDEX IF NOT EXISTS idx_quote_items_quote ON orcamento_itens(quote_id);
CREATE INDEX IF NOT EXISTS idx_quote_rules_quote ON orcamento_regras_snapshot(quote_id);
CREATE INDEX IF NOT EXISTS idx_retals_material_status ON estoque_retals(material_code, status);
CREATE INDEX IF NOT EXISTS idx_price_catalog_material_variant ON catalogo_precos(material_code, variant);
CREATE INDEX IF NOT EXISTS idx_price_history_material_variant ON historico_precos(material_code, variant, valid_from DESC);
CREATE INDEX IF NOT EXISTS idx_quote_price_snapshot_quote ON orcamento_precos_snapshot(quote_id);
CREATE INDEX IF NOT EXISTS idx_quote_pricing_snapshot_quote ON orcamento_formacao_preco_snapshot(quote_id);
